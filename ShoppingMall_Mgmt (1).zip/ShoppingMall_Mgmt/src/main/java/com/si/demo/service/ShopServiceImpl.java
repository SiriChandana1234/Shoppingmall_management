package com.si.demo.service;

import java.util.List;
import java.util.Objects;

import org.hibernate.query.NativeQuery.ReturnableResultNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.si.demo.entity.Shop;
import com.si.demo.repository.ShopRepository;

@Service
public class ShopServiceImpl implements ShopService {
@Autowired
 private ShopRepository r1;
@Override
public Shop saveShop(Shop shop) {
	return r1.save(shop);
}
@Override
public List<Shop>fetchShopList(){
	return r1.findAll();
}
@Override
public Shop fetchShopById(Long shopId) {
	return r1.findById(shopId).get();
}
@Override
public void deleteShopById(Long shopId) {
	r1.deleteById(shopId);
}
@Override
public Shop updateShop(Long shopId, Shop shop) {
	Shop shopDB = r1.findById(shopId).get();
	
	if (Objects.nonNull(shop.getShopName())&&
			!"".equalsIgnoreCase(shop.getShopName())){
		shopDB.setShopName(shop.getShopName());
	}
	return r1.save(shopDB);
		
	}
}

