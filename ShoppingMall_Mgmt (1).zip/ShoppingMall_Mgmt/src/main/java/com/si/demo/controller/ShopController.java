package com.si.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.si.demo.entity.Shop;
import com.si.demo.service.ShopService;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;



@RestController
public class ShopController {
@Autowired
ShopService s1;
@PostMapping("/Shop")
public Shop saveShop(@RequestBody Shop shop) {
	
	return s1.saveShop(shop);
	
}
@GetMapping("/Shop")
public List<Shop> fetchShopList() {
    return s1.fetchShopList();
}
@GetMapping("/Shop/{id}")
public Shop fetchShopById(@PathVariable("id")Long shopId) {
    return s1.fetchShopById(shopId);
}
@DeleteMapping("/Shop/{id}")
public String deleteShopById(@PathVariable("id")Long shopId) {
	s1.deleteShopById(shopId);
return " Shop deleted successfully";
}
}
